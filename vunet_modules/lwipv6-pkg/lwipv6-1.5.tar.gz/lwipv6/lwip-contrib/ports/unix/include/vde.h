#ifndef VDESTDSOCK
#define VDESTDSOCK	"/var/run/vde.ctl"
#define VDETMPSOCK	"/tmp/vde.ctl"
#endif

#define DO_SYSLOG
#define VDE_IP_LOG
